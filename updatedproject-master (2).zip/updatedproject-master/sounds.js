function playMarshmallow(){
  var audio = document.getElementById('audio1');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playWaves(){
  var audio = document.getElementById('audio2');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playdrop(){
  var audio = document.getElementById('audio3');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playtrain(){
  var audio = document.getElementById('audio4');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playthunder(){
  var audio = document.getElementById('audio5');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playcity(){
  var audio = document.getElementById('audio6');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playwasher(){
  var audio = document.getElementById('audio7');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playcricket(){
  var audio = document.getElementById('audio8');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}

function playfan(){
  var audio = document.getElementById('audio9');
  if(audio.paused){
    audio.play();
  }
  else{
    audio.pause();
  }
}
var random_list = [playfan(),playcricket(),playwasher()]
function randomnum(){
  var sounds = document.getElementsByTagName('audio');
  for(i=0;i< sounds.length;i++) sounds[i].pause();

  num = Math.floor((Math.random()*3) +1)
  if(num ==1){
    playfan();
  }
  if(num ==2){
    playcricket();
  }
  if(num == 3){
    playwasher();
  }

}
function relaxnu(){
  var sounds = document.getElementsByTagName('audio');
  for(i=0;i< sounds.length;i++) sounds[i].pause();

  num = Math.floor((Math.random()*3) +1)
  if(num ==1){
    playfan();
  }
  if(num ==2){
    playcricket();
  }
  if(num == 3){
    playwasher();
  }

}
function prodnu(){
  var sounds = document.getElementsByTagName('audio');
  for(i=0;i< sounds.length;i++) sounds[i].pause();

  num = Math.floor((Math.random()*3) +1)
  if(num ==1){
    playfan();
  }
  if(num ==2){
    playcricket();
  }
  if(num == 3){
    playwasher();
  }

}
function stopnu(){
  var sounds = document.getElementsByTagName('audio');
  for(i=0;i< sounds.length;i++) sounds[i].pause();
}
